<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/styleIndex.css">
        <title>Index</title>
        <link rel="icon" type="image/png" href="icona.png">
    </head>
    <body>
        <button><a href="login.php">Login</a></button>
        <button><a href="registrati.php">Registrati</a></button>
    </body>
</html>